# Barber Flow

SaaS multi-tenant para gestão de barbearias.

## Stack
- Next.js
- Supabase
- Vercel

## Configuração
Crie `.env.local` a partir de `.env.example` e configure:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

Nunca coloque a service role key no navegador ou no GitHub.
