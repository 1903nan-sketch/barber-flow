import Link from "next/link";

export default function Home() {
  return (
    <main className="landing">
      <nav className="nav">
        <div className="brand"><span>BF</span> Barber Flow</div>
        <Link className="ghost" href="/login">Entrar</Link>
      </nav>
      <section className="hero">
        <div>
          <p className="eyebrow">GESTÃO PARA BARBEARIAS</p>
          <h1>Sua barbearia organizada em um único lugar.</h1>
          <p className="lead">Agenda, clientes, serviços, vendas, estoque, comissões e gestão da equipe em uma plataforma preparada para múltiplas unidades.</p>
          <div className="actions">
            <Link className="primary" href="/login">Acessar Barber Flow</Link>
          </div>
        </div>
        <div className="preview">
          <div className="previewTop"><b>Barber Flow</b><span>Online</span></div>
          <div className="metrics">
            <div><small>Agenda hoje</small><strong>12</strong></div>
            <div><small>Faturamento</small><strong>R$ 840</strong></div>
          </div>
          <div className="fakeList">
            <p><b>09:00</b> Corte • João</p>
            <p><b>10:00</b> Barba • Carlos</p>
            <p><b>11:30</b> Corte + Barba • Lucas</p>
          </div>
        </div>
      </section>
    </main>
  );
}
