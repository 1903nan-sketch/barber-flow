const modules=[
  ["Agenda","Horários, bloqueios e atendimentos"],
  ["Clientes","Cadastro e histórico"],
  ["Serviços","Preços e duração"],
  ["Equipe","Barbeiros e permissões"],
  ["Vendas","Comandas e recebimentos"],
  ["Estoque","Produtos e movimentações"],
  ["Comissões","Acompanhamento da equipe"],
  ["Relatórios","Indicadores da barbearia"]
];

export default function Dashboard(){
 return <main className="shell">
  <header className="top"><div><p className="eyebrow">BARBER FLOW</p><h1>Painel da barbearia</h1></div><div className="pill">Operação</div></header>
  <section className="stats">
   <div className="stat"><small>Atendimentos hoje</small><strong>—</strong></div>
   <div className="stat"><small>Vendas hoje</small><strong>—</strong></div>
   <div className="stat"><small>Clientes</small><strong>—</strong></div>
  </section>
  <section className="grid">{modules.map(([a,b])=><article className="module" key={a}><h2>{a}</h2><p>{b}</p><button>Abrir</button></article>)}</section>
 </main>
}
