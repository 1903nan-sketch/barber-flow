"use client";
import { useEffect,useState } from "react";
import { createClient } from "../../lib/supabase";

export default function Admin(){
 const [shops,setShops]=useState([]);
 const [status,setStatus]=useState("Carregando...");
 useEffect(()=>{(async()=>{
  try{
   const s=createClient();
   const {data:{user}}=await s.auth.getUser();
   if(!user){location.href="/login";return;}
   const {data:p}=await s.from("profiles").select("role").eq("id",user.id).single();
   if(p?.role!=="platform_admin"){location.href="/dashboard";return;}
   const {data,error}=await s.from("barbershops").select("id,name,slug,active,city,state").order("created_at",{ascending:false});
   if(error) throw error;
   setShops(data||[]); setStatus("");
  }catch(e){setStatus(e.message);}
 })()},[]);
 return <main className="shell">
  <header className="top"><div><p className="eyebrow">PAINEL MESTRE</p><h1>Barbearias</h1></div><button className="primary">+ Nova barbearia</button></header>
  <section className="card">
   {status && <p>{status}</p>}
   {!status && shops.length===0 && <p className="muted">Nenhuma barbearia encontrada.</p>}
   {shops.map(x=><div className="shop" key={x.id}><div><b>{x.name}</b><small>{x.city||"—"}{x.state?` • ${x.state}`:""}</small></div><span className={x.active?"on":"off"}>{x.active?"Ativa":"Bloqueada"}</span></div>)}
  </section>
 </main>
}
