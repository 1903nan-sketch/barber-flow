"use client";
import { useEffect,useState } from "react";
import { createClient } from "../../../lib/supabase";

export default function Booking({params}){
 const [shop,setShop]=useState(null);
 const [services,setServices]=useState([]);
 const [pros,setPros]=useState([]);
 const [state,setState]=useState("Carregando...");
 useEffect(()=>{(async()=>{
  try{
   const slug=(await params).slug;
   const s=createClient();
   const {data:b,error}=await s.from("barbershops").select("id,name,city,state").eq("slug",slug).eq("active",true).eq("public_booking_enabled",true).single();
   if(error) throw error;
   setShop(b);
   const [{data:sv},{data:pr}]=await Promise.all([
    s.from("services").select("id,name,price,duration_minutes").eq("barbershop_id",b.id).eq("active",true),
    s.from("professionals").select("id,name").eq("barbershop_id",b.id).eq("active",true)
   ]);
   setServices(sv||[]); setPros(pr||[]); setState("");
  }catch(e){setState("Página de agendamento indisponível.");}
 })()},[params]);
 return <main className="center"><section className="card booking">
  {state ? <p>{state}</p> : <>
   <p className="eyebrow">AGENDAMENTO ONLINE</p><h1>{shop?.name}</h1>
   <p className="muted">{shop?.city}{shop?.state?` • ${shop.state}`:""}</p>
   <h2>Escolha o serviço</h2>
   {services.map(x=><div className="choice" key={x.id}><div><b>{x.name}</b><small>{x.duration_minutes} min</small></div><strong>R$ {Number(x.price).toFixed(2).replace(".",",")}</strong></div>)}
   <h2>Profissional</h2>
   {pros.map(x=><div className="choice" key={x.id}><b>{x.name}</b></div>)}
   <p className="notice">Seleção de data/horário e confirmação serão ativadas na próxima etapa da integração.</p>
  </>}
 </section></main>
}
