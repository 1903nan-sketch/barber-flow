"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "../../lib/supabase";

export default function Login() {
  const router = useRouter();
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [message,setMessage]=useState("");
  const [loading,setLoading]=useState(false);

  async function submit(e){
    e.preventDefault();
    setLoading(true); setMessage("");
    try {
      const supabase=createClient();
      const {data,error}=await supabase.auth.signInWithPassword({email,password});
      if(error) throw error;
      const {data:profile,error:profileError}=await supabase
        .from("profiles").select("role,active").eq("id",data.user.id).single();
      if(profileError) throw profileError;
      if(!profile?.active){ await supabase.auth.signOut(); throw new Error("Acesso desativado."); }
      router.push(profile.role==="platform_admin"?"/admin":"/dashboard");
    } catch(err){ setMessage(err.message || "Não foi possível entrar."); }
    finally { setLoading(false); }
  }

  return <main className="center">
    <form className="card loginCard" onSubmit={submit}>
      <div className="logo">BF</div>
      <h1>Barber Flow</h1>
      <p className="muted">Entre para gerenciar sua barbearia.</p>
      <label>E-mail<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label>
      <label>Senha<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></label>
      {message && <div className="error">{message}</div>}
      <button className="primary full" disabled={loading}>{loading?"Entrando...":"Entrar"}</button>
    </form>
  </main>;
}
